/*Debemos lograr tomar nombre y edad por ID y mostrarlos concatenados 
ej.: "Usted se llama José y tiene 66 años" 	*/
function mostrar()
{	
	var nombre;
	var edad;

	//document.getElementById("elNombre").value=nombre;
	//document.getElementById("laEdad").value=edad;

	//elNombre.value=nombre;
	//laEdad.value=edad;

	nombre=elNombre.value
	edad=laEdad.value



	//alert(nombre+edad);
	alert("Usted se llama "+nombre+" y tiene "+edad+" años");

}

